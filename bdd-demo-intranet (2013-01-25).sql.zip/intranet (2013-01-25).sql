-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Ven 25 Janvier 2013 à 20:35
-- Version du serveur: 5.5.9
-- Version de PHP: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `intranet`
--

-- --------------------------------------------------------

--
-- Structure de la table `civilite`
--

CREATE TABLE `civilite` (
  `ID_CIVILITE` int(11) NOT NULL AUTO_INCREMENT,
  `VALEUR` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  PRIMARY KEY (`ID_CIVILITE`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `civilite`
--

INSERT INTO `civilite` VALUES(1, 'Mlle');
INSERT INTO `civilite` VALUES(2, 'Mme');
INSERT INTO `civilite` VALUES(3, 'M.');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `ID_CLIENT` int(11) NOT NULL AUTO_INCREMENT,
  `ID_LOGIN` int(11) NOT NULL,
  `DATE_HEURE` datetime NOT NULL,
  `ENTREPRISE` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `CIVILITE` int(11) NOT NULL,
  `NOM` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `PRENOM` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `ADRESSE_01` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `ADRESSE_02` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `VILLE` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `CODE_POSTAL` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `TEL_BUREAU` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `TEL_DOMICILE` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `TEL_MOBILE` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `EMAIL` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  PRIMARY KEY (`ID_CLIENT`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `client`
--

INSERT INTO `client` VALUES(1, 1, '2012-08-08 20:25:21', 'Web agency', 3, 'DURANT', 'Eric', '48 rue de adresse', '', 'BORDEAUX', '33000', '05 01 02 03 04', '05 04 03 02 01', '06 01 02 03 04', 'eric@mywebsite.com');
INSERT INTO `client` VALUES(2, 1, '2013-01-25 20:28:17', '', 3, 'DUPONT', 'George', '98 rue de adresse', '', 'PARIS', '75000', '01 02 03 04 05', '01 05 04 03 02', '07 01 02 03 04', 'george@monsite.com');

-- --------------------------------------------------------

--
-- Structure de la table `droit`
--

CREATE TABLE `droit` (
  `ID_DROIT` int(11) NOT NULL AUTO_INCREMENT,
  `VALEUR` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  PRIMARY KEY (`ID_DROIT`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `droit`
--

INSERT INTO `droit` VALUES(1, 'admin');
INSERT INTO `droit` VALUES(2, 'standard');

-- --------------------------------------------------------

--
-- Structure de la table `etat`
--

CREATE TABLE `etat` (
  `ID_ETAT` int(11) NOT NULL AUTO_INCREMENT,
  `VALEUR` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `QUI` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  PRIMARY KEY (`ID_ETAT`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=13 ;

--
-- Contenu de la table `etat`
--

INSERT INTO `etat` VALUES(1, 'Cree', 'ficheCommande');
INSERT INTO `etat` VALUES(2, 'En cours', 'ficheCommande');
INSERT INTO `etat` VALUES(3, 'Recu', 'ficheCommande');
INSERT INTO `etat` VALUES(4, 'Pret', 'ficheCommande');
INSERT INTO `etat` VALUES(5, 'Facture', 'ficheCommande');
INSERT INTO `etat` VALUES(6, 'Depot', 'sav');
INSERT INTO `etat` VALUES(7, 'En cours', 'sav');
INSERT INTO `etat` VALUES(8, 'Devis fait', 'sav');
INSERT INTO `etat` VALUES(9, 'Prevenu', 'sav');
INSERT INTO `etat` VALUES(10, 'Devis accepte', 'sav');
INSERT INTO `etat` VALUES(11, 'Fini', 'sav');
INSERT INTO `etat` VALUES(12, 'Client venu chercher materiel', 'sav');

-- --------------------------------------------------------

--
-- Structure de la table `ficheCommande`
--

CREATE TABLE `ficheCommande` (
  `ID_FICHECOMMANDE` int(11) NOT NULL AUTO_INCREMENT,
  `ID_LOGIN` int(11) NOT NULL,
  `ID_CLIENT` int(11) NOT NULL,
  `ID_FOURNISSEUR` int(11) NOT NULL,
  `ID_ETAT` int(11) NOT NULL,
  `ID_SAGE` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `CONTACT_COMMERCIAL` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `CONTACT_TECHNIQUE` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `DATE_CREATION` date NOT NULL,
  `DATE_LIVRAISON` date NOT NULL,
  `DATE_EN_COURS` date NOT NULL,
  `DATE_RECU` date NOT NULL,
  `DATE_LIVRE` date NOT NULL,
  `DATE_FACTURE` date NOT NULL,
  `REF` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `DESIGNATION` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `QUANTITE` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `COMMENTAIRE` text COLLATE latin1_german2_ci NOT NULL,
  PRIMARY KEY (`ID_FICHECOMMANDE`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `ficheCommande`
--

INSERT INTO `ficheCommande` VALUES(1, 1, 2, 2, 3, '', '1', '2', '2013-01-25', '2013-01-10', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '', '', 'mon commentaire ici');
INSERT INTO `ficheCommande` VALUES(2, 1, 2, 3, 2, '', '1', '2', '2013-01-25', '2013-01-08', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '', '', 'mon commentaire ici');
INSERT INTO `ficheCommande` VALUES(3, 1, 1, 1, 4, '', '1', '2', '2013-01-25', '2013-01-04', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '', '', '', 'mon commentaire ici');

-- --------------------------------------------------------

--
-- Structure de la table `fournisseur`
--

CREATE TABLE `fournisseur` (
  `ID_FOURNISSEUR` int(11) NOT NULL AUTO_INCREMENT,
  `VALEUR` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  PRIMARY KEY (`ID_FOURNISSEUR`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=17 ;

--
-- Contenu de la table `fournisseur`
--

INSERT INTO `fournisseur` VALUES(1, 'APPLE');
INSERT INTO `fournisseur` VALUES(2, 'DELL');
INSERT INTO `fournisseur` VALUES(3, 'MICROSOFT');
INSERT INTO `fournisseur` VALUES(4, 'EEWEE');

-- --------------------------------------------------------

--
-- Structure de la table `login`
--

CREATE TABLE `login` (
  `ID_LOGIN` int(11) NOT NULL AUTO_INCREMENT,
  `CIVILITE` int(11) NOT NULL,
  `NOM` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `PRENOM` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `EMAIL` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `MDP` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `DROIT` int(11) NOT NULL,
  `ACTIVE` int(1) NOT NULL DEFAULT '1',
  `SALT` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  PRIMARY KEY (`ID_LOGIN`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=14 ;

--
-- Contenu de la table `login`
--

INSERT INTO `login` VALUES(1, 3, 'SMITH', 'Bob', 'bob@eewee.fr', '34819d7beeabb9260a5c854bc85b3e44', 1, 1, '');
INSERT INTO `login` VALUES(2, 3, 'ANDERSON', 'Peter', 'peter@eewee.fr', 'e3ff8a8836071936a80e046511d3630a', 2, 1, '');

-- --------------------------------------------------------

--
-- Structure de la table `mainOeuvre`
--

CREATE TABLE `mainOeuvre` (
  `ID_MAINOEUVRE` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `VALEUR` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `PRIX` float NOT NULL,
  `QUI` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  PRIMARY KEY (`ID_MAINOEUVRE`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=30 ;

--
-- Contenu de la table `mainOeuvre`
--

INSERT INTO `mainOeuvre` VALUES(1, '1 heure', 15, 'pro');
INSERT INTO `mainOeuvre` VALUES(2, '1 heure', 15, 'particulier');
INSERT INTO `mainOeuvre` VALUES(3, '2 heures', 30, 'pro');
INSERT INTO `mainOeuvre` VALUES(4, '2 heures', 30, 'particulier');
INSERT INTO `mainOeuvre` VALUES(5, '3 heures', 45, 'pro');
INSERT INTO `mainOeuvre` VALUES(6, '3 heures', 45, 'particulier');
INSERT INTO `mainOeuvre` VALUES(7, '4 heures', 55, 'pro');
INSERT INTO `mainOeuvre` VALUES(8, '4 heures', 55, 'particulier');
INSERT INTO `mainOeuvre` VALUES(9, '5 heures', 60, 'pro');
INSERT INTO `mainOeuvre` VALUES(10, '5 heures', 60, 'particulier');
INSERT INTO `mainOeuvre` VALUES(11, '6 heures', 65, 'pro');
INSERT INTO `mainOeuvre` VALUES(12, '6 heures', 65, 'particulier');

-- --------------------------------------------------------

--
-- Structure de la table `pret`
--

CREATE TABLE `pret` (
  `ID_PRET` int(11) NOT NULL AUTO_INCREMENT,
  `ID_CLIENT` int(11) NOT NULL,
  `ID_PRETEUR` int(11) NOT NULL,
  `DATE_DEBUT_PRET` date NOT NULL,
  `DATE_FIN_PRET` date NOT NULL,
  `TYPE_MATERIEL` text COLLATE latin1_german2_ci NOT NULL,
  `ARCHIVE` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID_PRET`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=43 ;

--
-- Contenu de la table `pret`
--

INSERT INTO `pret` VALUES(1, 97, 3, '2013-01-05', '2013-01-20', 'Blue car 5536.', 1);
INSERT INTO `pret` VALUES(2, 44, 3, '2013-02-02', '2013-02-04', 'Ecran TV', 1);
INSERT INTO `pret` VALUES(3, 141, 3, '2013-02-15', '2013-03-02', 'Livre sur le PHP5', 1);
INSERT INTO `pret` VALUES(4, 160, 3, '2013-02-15', '2013-05-16', 'Souris', 1);
INSERT INTO `pret` VALUES(42, 1, 0, '2012-11-01', '2012-12-31', 'iPhone', 0);
INSERT INTO `pret` VALUES(41, 1, 0, '2012-11-01', '2012-12-31', 'iPad', 0);
INSERT INTO `pret` VALUES(40, 2, 0, '2013-01-01', '2013-01-31', 'iMac', 0);

-- --------------------------------------------------------

--
-- Structure de la table `sav`
--

CREATE TABLE `sav` (
  `ID_SAV` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ID_LOGIN` int(11) NOT NULL,
  `ID_CLIENT` int(11) NOT NULL,
  `DATE_CREATION` date NOT NULL,
  `DATE_LIVRAISON` date NOT NULL,
  `CONTACT_COMMERCIAL` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `CONTACT_TECHNIQUE` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `ACCESSOIRE_CLIENT` text COLLATE latin1_german2_ci NOT NULL,
  `COMMENTAIRE_PANNE` text COLLATE latin1_german2_ci NOT NULL,
  `COMMENTAIRE_REPARATION` text COLLATE latin1_german2_ci NOT NULL,
  `FACTURATION_MAIN_OEUVRE` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `FACTURATION_MATERIEL` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `MAIN_OEUVRE` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `QUANTITE_MAIN_OEUVRE` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `PIECE` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `QUANTITE_PIECE` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `PRIX_PIECE` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `ID_ETAT` int(11) NOT NULL,
  `NUMERO_DEVIS` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `MOT_DE_PASSE` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `PRIX_TOTAL` float NOT NULL,
  PRIMARY KEY (`ID_SAV`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `sav`
--

INSERT INTO `sav` VALUES(1, 1, 2, '2013-01-25', '2013-01-05', '1', '2', 'aucun', 'plus rien ne fonctionne', 'alimentation changée', '', '', '', '', '', '', '', 6, '', '', 0);
INSERT INTO `sav` VALUES(2, 1, 1, '2013-01-25', '2013-01-10', '1', '2', 'rien', 'ajouter logiciel open office', 'installation en cours', '', '', '', '', '', '', '', 7, '', '54785', 0);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) DEFAULT NULL,
  `password_salt` varchar(32) DEFAULT NULL,
  `real_name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `users`
--

INSERT INTO `users` VALUES(1, 'admin', 'mypasswordhere', 'rien', 'Michael');
