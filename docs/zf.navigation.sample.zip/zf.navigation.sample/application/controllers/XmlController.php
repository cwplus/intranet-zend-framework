<?php

class XmlController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        // action body
    }

	public function sampleAction()
    {
        // action body
    }
    
	public function testAction()
    {
        // action body
    }

}

