<?php

class SitemapController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        // action body
    }

	public function categoriesAction()
    {
        // action body
    }
    
	public function productsAction()
    {
        // action body
    }

}

